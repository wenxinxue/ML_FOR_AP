# ML Model Benchmarking Pipeline

This repository provides a clean benchmarking pipeline for comparing multiple machine learning models on a binary classification task.

## Features
- Data preprocessing with missing-value handling
- Standardization
- Comparison of 16 machine learning models
- Train/test evaluation
- Cross-validation
- Export of results to CSV/XLSX
- Automatic text report generation

## Input
Update the file path in `main()`:

```python
filepath = "/path/to/AP.csv"
```

The input CSV is expected to contain:
- all predictors in the first columns
- the binary target variable in the last column

## Run
```bash
python model_benchmark.py
```

## Outputs
- `X_train_before_impute.csv`
- `X_test_before_impute.csv`
- `all_models_comparison.csv`
- `all_models_comparison.xlsx`
- `model_comparison_report.txt`
